import os
import numpy as np
import cv2
import base64
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import tensorflow as tf
from concurrent.futures import ThreadPoolExecutor
from typing import List
import tensorflow_addons as tfa
from PIL import Image
import io
import asyncio
import uvicorn
import logging
from tensorflow.config.experimental import set_memory_growth

# 配置日志
logging.basicConfig(level=logging.INFO)

# 配置GPU内存动态增长
gpus = tf.config.list_physical_devices('GPU')
if gpus:
    try:
        for gpu in gpus:
            set_memory_growth(gpu, True)
    except RuntimeError as e:
        print(e)

app = FastAPI(title="Ocular Diagnosis API")

# CORS配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# 全局配置
CLASS_NAMES = ['N','D','G','C','A','H','M','O']
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5MB  # 传入限制
MAX_BATCH_SIZE = 32  # 批次

# IMAGE_SIZE = (244, 244) # 输入给模型的图片
IMAGE_SIZE = (224, 224) # 输入给模型的图片
DISPLAY_SIZE = (448, 448) # 显示的图片大小

# 自定义函数定义（需与训练代码完全一致）
class_weights = tf.constant([1.0, 2.5, 3.0, 2.0, 4.0, 5.0, 1.5, 1.2], dtype=tf.float32)

def weighted_bce(y_true, y_pred):
    weights = tf.reduce_sum(class_weights * y_true, axis=1)
    bce = tf.keras.losses.binary_crossentropy(y_true, y_pred)
    return tf.reduce_mean(bce * weights)

# 加载模型（增加所有自定义对象）
# model_path = r"saved_models_3/final_model"
model_path = r"saved_models_224*224_oia/final_model"
if not os.path.exists(model_path):
    raise FileNotFoundError(f"Model file not found at {model_path}")

model = tf.keras.models.load_model(
    model_path,
    custom_objects={
        "AdamW": tfa.optimizers.AdamW,
        "weighted_bce": weighted_bce,
        "F1Score": tfa.metrics.F1Score,
        "swish": tf.nn.swish
    }
)
model.run_eagerly = False  # 启用图模式加速

# 线程池配置
executor = ThreadPoolExecutor(
    max_workers=4,
    thread_name_prefix="preprocess_worker"
)

# 响应模型
class DiagnosisResult(BaseModel):
    filenames: List[str]
    predictions: dict
    combined_image: str
    confidence_analysis: dict  # 新增置信度分析

# 验证函数
def validate_image(file: UploadFile):
    if file.content_type not in ["image/jpeg", "image/png"]:
        raise HTTPException(400, "仅支持JPEG/PNG格式")
    if file.size > MAX_IMAGE_SIZE:
        raise HTTPException(413, f"文件过大: {file.filename}")

# 预处理函数（与训练对齐）
def batch_preprocess(images: List[np.ndarray]) -> np.ndarray:
    """与训练预处理完全一致的实现"""
    processed = []
    for img in images:
        # 尺寸调整使用双线性插值
        resized = cv2.resize(img, IMAGE_SIZE, interpolation=cv2.INTER_LINEAR)
        
        # OpenCV BGR转RGB
        rgb_img = cv2.cvtColor(resized, cv2.COLOR_BGR2RGB)
        
        # 归一化到[0,1]范围
        normalized = rgb_img.astype(np.float32) / 255.0
        
        processed.append(normalized)
    return np.array(processed)

# 图像处理流程
async def process_image(file: UploadFile) -> np.ndarray:
    content = await file.read()
    img = cv2.imdecode(np.frombuffer(content, np.uint8), cv2.IMREAD_COLOR)
    if img is None:
        raise HTTPException(400, f"无效的图片文件: {file.filename}")
    
    # 添加尺寸验证
    h, w = img.shape[:2]
    if h < 200 or w < 200:
        raise HTTPException(400, f"图像尺寸过小: {file.filename} ({w}x{h})")
    
    return img  # 保持BGR格式，后续预处理转换

# 生成拼接图像
def generate_combined_image(left: np.ndarray, right: np.ndarray) -> str:
    resized_left = cv2.resize(left, DISPLAY_SIZE)
    resized_right = cv2.resize(right, DISPLAY_SIZE)
    combined = np.hstack([resized_left, resized_right])
    
    # 转换为JPEG字节流
    _, buffer = cv2.imencode('.jpg', combined)
    return f"data:image/jpeg;base64,{base64.b64encode(buffer).decode()}"

# 主预测接口
@app.post("/predict", response_model=List[DiagnosisResult])
async def batch_predict(files: List[UploadFile] = File(...)):
    try:
        # 输入验证
        if len(files) % 2 != 0:
            raise HTTPException(400, "需要成对的左右眼图片")
        for file in files:
            validate_image(file)

        pairs = [(files[i], files[i+1]) for i in range(0, len(files), 2)]
        results = []

        # 分批次处理
        for batch_idx in range(0, len(pairs), MAX_BATCH_SIZE):
            current_batch = pairs[batch_idx:batch_idx+MAX_BATCH_SIZE]
            
            # 并行处理图像
            left_images = await asyncio.gather(*[process_image(p[0]) for p in current_batch])
            right_images = await asyncio.gather(*[process_image(p[1]) for p in current_batch])

            # 异步预处理
            loop = asyncio.get_event_loop()
            left_batch = await loop.run_in_executor(executor, batch_preprocess, left_images)
            right_batch = await loop.run_in_executor(executor, batch_preprocess, right_images)

            # 模型预测
            preds = model.predict(
                [left_batch, right_batch],
                batch_size=MAX_BATCH_SIZE,
                verbose=0
            )

            # 生成结果
            for i, ((left_file, right_file), pred) in enumerate(zip(current_batch, preds)):
                pred_dict = {c: float(p) for c, p in zip(CLASS_NAMES, pred)}
                results.append(DiagnosisResult(
                    filenames=[left_file.filename, right_file.filename],
                    predictions=pred_dict,
                    combined_image=generate_combined_image(left_images[i], right_images[i]),
                    confidence_analysis={
                        "max_confidence": max(pred_dict.values()),
                        "min_confidence": min(pred_dict.values()),
                        "mean_confidence": sum(pred_dict.values())/len(pred_dict)
                    }
                ))

        return results

    except HTTPException as he:
        return JSONResponse(content={"error": he.detail}, status_code=he.status_code)
    except Exception as e:
        logging.error(f"Unexpected error: {e}", exc_info=True)
        return JSONResponse(content={"error": str(e)}, status_code=500)

# 调试接口（特征验证）
@app.post("/debug_predict")
async def debug_predict(files: List[UploadFile] = File(...)):
    try:
        left = await process_image(files[0])
        right = await process_image(files[1])
        
        # 预处理
        left_batch = batch_preprocess([left])
        right_batch = batch_preprocess([right])
        
        # 获取特征
        feature_model = tf.keras.Model(
            inputs=model.input,
            outputs=model.layers[-3].output
        )
        features = feature_model.predict([left_batch, right_batch])
        
        return {
            "features": features.tolist(),
            "predictions": model.predict([left_batch, right_batch]).tolist()
        }
        
    except Exception as e:
        return JSONResponse(
            status_code=500,
            content={"error": f"Debug error: {str(e)}"}
        )

if __name__ == "__main__":
    # 性能优化配置
    os.environ['TF_GPU_THREAD_MODE'] = 'gpu_private'
    os.environ['TF_ENABLE_GPU_GARBAGE_COLLECTION'] = 'true'
    
    uvicorn.run(
        app,
        host="0.0.0.0",
        port=6006,
        timeout_keep_alive=300,
        limit_concurrency=100
    )
    # uvicorn main_will:app --host 0.0.0.0 --port 6006
    # ps aux | grep uvicorn 显示进程
    # kill -9 pid 强制杀死所有进程
    