//token加密密钥
module.exports={
    jwtSecretKey:"ljy666*",
    expiresIn:'10h'
}